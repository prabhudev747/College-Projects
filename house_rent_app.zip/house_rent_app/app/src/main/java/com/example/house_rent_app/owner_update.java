package com.example.house_rent_app;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class owner_update extends AppCompatActivity {
    EditText ed1,ed2,ed3,ed4,ed5,ed6;
    Button b1;
    dbhelperclass dbhobj;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_update);
        dbhobj=new dbhelperclass(this);
        ed1=(EditText)findViewById(R.id.editText);
        ed2=(EditText)findViewById(R.id.editText2);
        ed3=(EditText)findViewById(R.id.editText3);
ed4=(EditText)findViewById(R.id.editText4);
ed5=(EditText)findViewById(R.id.editText5);
ed6=(EditText)findViewById(R.id.editText6);
        b1=(Button)findViewById(R.id.update);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean update=dbhobj.updateData(ed1.getText().toString(),ed2.getText().toString(),ed3.getText().toString(),ed4.getText().toString(),ed5.getText().toString(),ed6.getText().toString());
                if(update==true)
                {
                    Toast.makeText(owner_update.this,"data updated",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(owner_update.this,"data not updated",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
