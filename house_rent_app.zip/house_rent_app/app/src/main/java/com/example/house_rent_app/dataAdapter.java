package com.example.house_rent_app;


import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


public class dataAdapter extends ArrayAdapter<Contact>{
    customButtonListener customListner;
    dbhelperclass db;
    Context context;
    ArrayList<Contact> mcontact;


    public dataAdapter(Context context, ArrayList<Contact> contact){
        super(context, R.layout.listcontacts, contact);
        this.context=context;
        this.mcontact=contact;
    }
    public interface customButtonListener {
        public void onButtonClickListner(int position, Contact value);
    }

    public void setCustomButtonListner(customButtonListener listener) {
        this.customListner = listener;
    }

    public  class  Holder{
        TextView nameFV;
        Button details,ac,rej;
        ImageView pic;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
         db=new dbhelperclass(context);
        final Contact data = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view

        final Holder viewHolder; // view lookup cache stored in tag

        if (convertView == null) {


            viewHolder = new Holder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.listcontacts, parent, false);

            viewHolder.nameFV = (TextView) convertView.findViewById(R.id.txtViewer);
            viewHolder.pic = (ImageView) convertView.findViewById(R.id.imgView);
            viewHolder.details=(Button)convertView.findViewById(R.id.view_details);
            viewHolder.ac=(Button)convertView.findViewById(R.id.accept);
            viewHolder.rej=(Button)convertView.findViewById(R.id.reject);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (Holder) convertView.getTag();
        }


        viewHolder.nameFV.setText("owner name: "+data.getName());
        viewHolder.pic.setImageBitmap(convertToBitmap(data.get_img()));
        viewHolder.details.setTag(position);
        viewHolder.ac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.updateaccept(data.get_id()+"");

            }
        });
        viewHolder.rej.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.updatereject(data.get_id()+"");
            }
        });
         viewHolder.details.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 int a=position;


                 Intent i=new Intent(view.getContext(),details.class);

                 i.putExtra("name",data.get_id()+"");
                 i.putExtra("address",data.getAddress()+"");

                 view.getContext().startActivity(i);






             }
             });


        // Return the completed view to render on screen
        return convertView;
    }
    //get bitmap image from byte array

    private Bitmap convertToBitmap(byte[] b){

        return BitmapFactory.decodeByteArray(b, 0, b.length);

    }

}