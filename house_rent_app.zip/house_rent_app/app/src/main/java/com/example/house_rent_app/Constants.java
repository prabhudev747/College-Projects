package com.example.house_rent_app;

public class Constants {

    // Error Messages
    //public static final String MISSING_ID = "Please enter your ID";
    public static final String MISSING_NAME = "Please enter your name";
    public static final String MISSING_PASSWORD = "Please enter your password";
    public static final String MISSING_EMAIL = "Please enter your E-mail";
    public static final String MISSING_MOBILE = "Please enter your mobile number";
    public static final String INVALID_MAIL = "Invalid Mail";
    public static final int MINIMUM_PASSWORD_LENGTH = 8;
    public static final String INVALID_PASSWORD = "password must have character, number and special character";
    public static final String INVALID_MOBILE = "Invalid mobile number";
    public static final String MINIMUM_PASSWORD = "Minimum password length is 8";
    public static final String PASSWORD_MISMATCH = "password mismatch please enter correct password";
    public static final String UNREGISTERED_USER = "You are not registered with the app. Please register to continue";
    // public static final String FORGOT_PASSWORD = "You seem to have forgotten your password. The registered password has been sent to your registered mobile";


    public static final String INVALID_USER = "Wrong Credentials";
    public static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1;


    public static final int DATABASE_VERSION = 1;

    // Database name
    public static final String DATABASE_NAME = "ProximityAlert";

    // Database tables
    public static final String USER_REGISTER_TABLE = "UserModel";


    // Register Table
    public static final String USER_ID_KEY = "id";
    public static final String USER_USERNAME_KEY = "username";
    public static final String USER_PASSWORD_KEY = "password";
    public static final String USER_CONFIRMPASSWORD_KEY = "confirmpassword";
    public static final String USER_MAIL_KEY = "mail";
    public static final String USER_MOBILE_KEY = "mobile";



    // Feedback Table
    public static final String FEEDBACK_DESCRIPTION_KEY = "description";



}
