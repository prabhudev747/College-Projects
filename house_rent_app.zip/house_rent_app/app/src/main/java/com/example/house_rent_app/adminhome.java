package com.example.house_rent_app;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class adminhome extends AppCompatActivity {
    private static final String title[] = { "1bhk", "2bhk"};

    // Integer array for drawable images
    private static final Integer Images[] = { R.drawable.bhk1,
            R.drawable.fb2bhk };

    ArrayList<Items> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminhome);
        GridView grid;
        grid = (GridView) findViewById(R.id.grid);

        // Array list for storing data in Items class
        arrayList = new ArrayList<Items>();

        // For loop to add data in array list
        for (int i = 0; i < Images.length; i++) {
            arrayList.add(new Items(title[i], Images[i]));
        }

        // Setting data in custom adapter
        CustomGridViewAdapter adapter = new CustomGridViewAdapter(
                adminhome.this, arrayList);

        grid.setAdapter(adapter);

        adapter.notifyDataSetChanged();

        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos,
                                    long id) {
                if(pos==0) {

                    // Starting a new activity and passing image id
                    Intent in = new Intent(adminhome.this,
                            coustmer_view.class);

                    startActivity(in);
                }


            }
        });

        // String array for image titles


    }
}
