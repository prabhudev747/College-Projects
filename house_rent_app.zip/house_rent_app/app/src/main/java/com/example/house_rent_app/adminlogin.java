package com.example.house_rent_app;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class adminlogin extends AppCompatActivity {

    Button submit;
    EditText e1,e2;
    int counter=5;
    TextView textView1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminlogin);

        submit=(Button)findViewById(R.id.b1);
        e1=(EditText)findViewById(R.id.editText1);
        e2=(EditText)findViewById(R.id.editText2);
        textView1=(TextView)findViewById(R.id.textView4);
        textView1.setText("no of attempts remaining:5");
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validation(e1.getText().toString(), e2.getText().toString());
            }
        });
    }
    private void validation(String username,String password) {
        if ((e1.getText().toString().equals("admin")) && (e2.getText().toString().equals("1234"))) {
            Intent intent = new Intent(adminlogin.this, bhk1_view.class);
            startActivity(intent);
        } else {
            counter--;
            textView1.setText("no of attempts remaining:" + String.valueOf(counter));
            if (counter == 0) {
                submit.setEnabled(false);
            }
        }
    }

}