package com.example.house_rent_app;

public class Contact {

    //private variables
    int _id;

     String name;
     String area_sqft;
    String facilites;
     String person_limit;
    String address;
    String price;
    String mobile;
    String type;
  private int accept;

    byte[] _img;



    // Empty constructor
    public Contact(){

    }
    // constructor
    public Contact(int id, String name, String area_sqft, String facilites, String person_limit, String address, String price, String mobile, byte[] img, int accept)
        {       this._id = id;
        this.name = name;
        this.area_sqft = area_sqft;
        this.facilites= facilites ;
        this.person_limit=person_limit;
        this.address=address;
        this.price=price;
        this.mobile=mobile;
        this._img = img;


    }

    public Contact(int id, String name, String area_sqft, String facilites, String person_limit, String address, String price, String mobile){
        this._id = id;
        this.name = name;
        this.area_sqft = area_sqft;
        this.facilites= facilites ;
        this.person_limit=person_limit;
        this.address=address;
        this.price=price;
        this.mobile=mobile;
        this.accept=accept;


    }

    // constructor
    public Contact(String name, String area_sqft, String person_limit, String facilites,String address, String price, String mobile , byte[] img,String type ){

        this.name = name;
        this.area_sqft = area_sqft;

        this.person_limit=person_limit;
        this.facilites= facilites ;
        this.address=address;
        this.price=price;
        this.mobile=mobile;
        this._img = img;
        this.accept=accept;
        this.type=type;

    }

    public int getAccept() {
        return accept;
    }

    public void setAccept(int accept) {
        this.accept = accept;
    }
    public String getType(){return type;}
    public void setType(String type){this.type=type;}

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArea_sqft() {
        return area_sqft;
    }

    public void setArea_sqft(String area_sqft) {
        this.area_sqft = area_sqft;
    }

    public String getFacilites() {
        return facilites;
    }

    public void setFacilites(String facilites) {
        this.facilites = facilites;
    }

    public String getPerson_limit() {
        return person_limit;
    }

    public void setPerson_limit(String person_limit) {
        this.person_limit = person_limit;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPrice() {
        return price;
    }


    public void setPrice(String price) {
        this.price = price;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public byte[] get_img() {
        return _img;
    }

    public void set_img(byte[] _img) {
        this._img = _img;
    }
}

