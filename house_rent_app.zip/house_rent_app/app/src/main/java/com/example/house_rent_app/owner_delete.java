package com.example.house_rent_app;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class owner_delete extends AppCompatActivity {
    dbhelperclass db;
    EditText ed1;
    TextView t1;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db=new dbhelperclass(this);
        setContentView(R.layout.activity_owner_delete);
        ed1=(EditText)findViewById(R.id.editText);
        b1=(Button)findViewById(R.id.delete);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer deletrows=db.deletdata(ed1.getText().toString());
                if(deletrows>0)
                    Toast.makeText(owner_delete.this,"data deleted",Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(owner_delete.this,"data not deleted",Toast.LENGTH_SHORT).show();


            }
        });




    }
}
